﻿import 'dotenv/config'
import bcrypt from 'bcrypt'
import { eq } from 'drizzle-orm'
import { db } from '../db/index.js'
import { companies, users } from '../db/schema.js'

async function ensureCompany () {
  const name = 'BossOS Workspace'
  const slug = 'bossos-workspace'

  const existing = await db
    .select()
    .from(companies)
    .where(eq(companies.slug, slug))
    .limit(1)

  if (existing.length > 0) {
    console.log(`Company already exists: ${slug}`)
    return existing[0]
  }

  const inserted = await db
    .insert(companies)
    .values({
      name,
      slug,
      isActive: true
    })
    .returning()

  console.log(`Company created: ${slug}`)
  return inserted[0]
}

async function ensureAdminUser () {
  const email = 'alex@laurelstreetcreative.com'
  const password = 'Eclipse12!@#$'
  const fullName = 'Alex McDaniel'
  const role = 'admin'

  const existing = await db
    .select()
    .from(users)
    .where(eq(users.email, email))
    .limit(1)

  if (existing.length > 0) {
    console.log(`User already exists: ${email}`)
    return existing[0]
  }

  const passwordHash = await bcrypt.hash(password, 10)

  const inserted = await db
    .insert(users)
    .values({
      email,
      passwordHash,
      fullName,
      role,
      isActive: true
    })
    .returning()

  console.log(`Admin user created: ${email}`)
  return inserted[0]
}

async function main () {
  await ensureCompany()
  await ensureAdminUser()
  process.exit(0)
}

main().catch(err => {
  console.error('Seed failed:', err)
  process.exit(1)
})
