﻿import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import Layout from "../components/Layout";
import { API_BASE, getStoredToken } from "../lib/auth";
import ReportsDivisionSelect from "./reports/ReportsDivisionSelect";
import ReportsModulePanel from "./reports/ReportsModulePanel";
import RefrigerantLogCard, { type RefrigerantLog } from "./reports/RefrigerantLogCard";

type Division = {
  id: string;
  companyId: string;
  key: string;
  name: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
};

type DivisionModuleRow = {
  id: string;
  isEnabled: boolean;
  createdAt: string;
  updatedAt: string;
  module: {
    id: string;
    key: string;
    name: string;
    category: string;
    isActive: boolean;
    createdAt: string;
    updatedAt: string;
  };
};

type SprayFoamAreaLine = {
  id: string;
  jobLogId: string;
  lineNumber: number;
  areaDescription: string;
  jobType: string;
  foamType: string;
  squareFeet: string | null;
  thicknessInches: string | null;
  boardFeet: string | null;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
};

type SprayFoamMaterialLine = {
  id: string;
  jobLogId: string;
  areaLineId: string;
  lineNumber: number;
  foamType: string;
  manufacturer: string;
  lotNumber: string;
  setsUsed: string | null;
  theoreticalYieldPerSet: string | null;
  theoreticalTotalYield: string | null;
  actualYield: string | null;
  yieldPercent: string | null;
  createdAt: string;
  updatedAt: string;
};

type SprayFoamLog = {
  id: string;
  userId: string;
  companyKey: string;
  divisionKey: string | null;
  techNameSnapshot: string;
  customerName: string | null;
  jobNumber: string | null;
  jobDate: string | null;
  crewLead: string | null;
  helpersText: string | null;
  rigName: string | null;
  timeOnJob: string | null;
  ambientTempF: string | null;
  substrateTempF: string | null;
  humidityPercent: string | null;
  downtimeMinutes: number | null;
  downtimeReason: string | null;
  otherNotes: string | null;
  photosUploadedToHcp: boolean;
  notes: string | null;
  submittedAt: string;
  createdAt: string;
  updatedAt: string;
  lines: SprayFoamAreaLine[];
  areaLines: SprayFoamAreaLine[];
  materialLines: SprayFoamMaterialLine[];
};

function formatFoamTypeLabel(value: string) {
  return value
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function SprayFoamLogCard({ log }: { log: SprayFoamLog }) {
  const areaLines = log.areaLines ?? log.lines ?? [];
  const materialLines = log.materialLines ?? [];

  const totalBoardFeet = areaLines.reduce((sum, line) => {
    const value = line.boardFeet ? Number(line.boardFeet) : 0;
    return sum + (Number.isFinite(value) ? value : 0);
  }, 0);

  const totalSetsUsed = materialLines.reduce((sum, line) => {
    const value = line.setsUsed ? Number(line.setsUsed) : 0;
    return sum + (Number.isFinite(value) ? value : 0);
  }, 0);

  const theoreticalTotalYield = materialLines.reduce((sum, line) => {
    const value = line.theoreticalTotalYield ? Number(line.theoreticalTotalYield) : 0;
    return sum + (Number.isFinite(value) ? value : 0);
  }, 0);

  const overallYieldPercent =
    theoreticalTotalYield > 0
      ? ((totalBoardFeet / theoreticalTotalYield) * 100).toFixed(2)
      : "0.00";

  const setsByFoamType = materialLines.reduce<Record<string, number>>((acc, line) => {
    const foamType = line.foamType?.trim();
    const setsUsed = line.setsUsed ? Number(line.setsUsed) : 0;

    if (!foamType || !Number.isFinite(setsUsed)) {
      return acc;
    }

    acc[foamType] = (acc[foamType] || 0) + setsUsed;
    return acc;
  }, {});

  const foamTypeTotals = Object.entries(setsByFoamType).sort(([a], [b]) =>
    a.localeCompare(b)
  );

  return (
    <Link
      to={`/logs/${log.id}?type=spray-foam`}
      className="block rounded-3xl border border-white/10 bg-[#1a1a1a] p-4 shadow-2xl transition hover:border-white/20 hover:bg-white/[0.07]"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="text-lg font-black tracking-tight text-white">
            {log.customerName || "No customer name"}
          </div>
          <div className="mt-1 text-xs font-semibold uppercase tracking-[0.18em] text-orange-400">
            Spray Foam Job Log
          </div>
        </div>

        <div className="shrink-0 rounded-full bg-white/10 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.18em] text-white/70">
          {areaLines.length} {areaLines.length === 1 ? "Area" : "Areas"}
        </div>
      </div>

      <div className="mt-4 grid gap-x-6 gap-y-2 text-sm text-white/65 sm:grid-cols-2 xl:grid-cols-4">
        <div>
          <span className="font-semibold text-white/85">Job Date:</span> {log.jobDate || "N/A"}
        </div>
        <div>
          <span className="font-semibold text-white/85">Job:</span> {log.jobNumber || "N/A"}
        </div>
        <div>
          <span className="font-semibold text-white/85">Crew Lead:</span>{" "}
          {log.crewLead || log.techNameSnapshot}
        </div>
        <div>
          <span className="font-semibold text-white/85">Rig:</span> {log.rigName || "N/A"}
        </div>
        <div>
          <span className="font-semibold text-white/85">Board Feet:</span>{" "}
          {totalBoardFeet.toFixed(2)}
        </div>
        <div>
          <span className="font-semibold text-white/85">Sets:</span> {totalSetsUsed.toFixed(2)}
        </div>
        <div>
          <span className="font-semibold text-white/85">Yield %:</span> {overallYieldPercent}%
        </div>
      </div>

      {foamTypeTotals.length > 0 ? (
        <div className="mt-4 flex flex-wrap gap-2">
          {foamTypeTotals.map(([foamType, totalSets]) => (
            <div
              key={foamType}
              className="rounded-full border border-white/10 bg-black/20 px-3 py-2 text-xs font-semibold text-white"
            >
              <span className="text-white/60">{formatFoamTypeLabel(foamType)}:</span>{" "}
              {totalSets.toFixed(2)}
            </div>
          ))}
        </div>
      ) : null}
    </Link>
  );
}

export default function LogsPage() {
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [selectedDivisionId, setSelectedDivisionId] = useState("");
  const [selectedModuleKey, setSelectedModuleKey] = useState("");
  const [modules, setModules] = useState<DivisionModuleRow[]>([]);
  const [refrigerantLogs, setRefrigerantLogs] = useState<RefrigerantLog[]>([]);
  const [sprayFoamLogs, setSprayFoamLogs] = useState<SprayFoamLog[]>([]);
  const [loadingDivisions, setLoadingDivisions] = useState(true);
  const [loadingModules, setLoadingModules] = useState(true);
  const [loadingRefrigerantLogs, setLoadingRefrigerantLogs] = useState(false);
  const [loadingSprayFoamLogs, setLoadingSprayFoamLogs] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadDivisions() {
      try {
        setLoadingDivisions(true);
        setError("");

        const token = getStoredToken();
        const res = await fetch(`${API_BASE}/api/divisions`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await res.json();

        if (!res.ok) {
          setError(data?.error || "Failed to load divisions.");
          return;
        }

        const nextDivisions = Array.isArray(data.divisions)
          ? data.divisions.filter((division: Division) => division.isActive)
          : [];

        setDivisions(nextDivisions);

        if (nextDivisions.length > 0) {
          const hvacDivision = nextDivisions.find((division: Division) => division.key === "hvac");
          setSelectedDivisionId(hvacDivision?.id || nextDivisions[0].id);
        }
      } catch {
        setError("Could not reach API.");
      } finally {
        setLoadingDivisions(false);
      }
    }

    void loadDivisions();
  }, []);

  const selectedDivision = useMemo(
    () => divisions.find((division) => division.id === selectedDivisionId) || null,
    [divisions, selectedDivisionId]
  );

  useEffect(() => {
    async function loadDivisionModules() {
      if (!selectedDivisionId) {
        setModules([]);
        setSelectedModuleKey("");
        setLoadingModules(false);
        return;
      }

      try {
        setLoadingModules(true);
        setError("");

        const token = getStoredToken();
        const res = await fetch(`${API_BASE}/api/divisions/${selectedDivisionId}/modules`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await res.json();

        if (!res.ok) {
          setError(data?.error || "Failed to load division modules.");
          return;
        }

        const nextModules = Array.isArray(data.modules) ? data.modules : [];
        setModules(nextModules);
        setSelectedModuleKey("");
      } catch {
        setError("Could not reach API.");
      } finally {
        setLoadingModules(false);
      }
    }

    void loadDivisionModules();
  }, [selectedDivisionId]);

  useEffect(() => {
    async function loadRefrigerantLogs() {
      if (!selectedDivision?.key || selectedModuleKey !== "refrigerant-log") {
        setRefrigerantLogs([]);
        setLoadingRefrigerantLogs(false);
        return;
      }

      try {
        setLoadingRefrigerantLogs(true);
        setError("");

        const token = getStoredToken();
        const url = new URL(`${API_BASE}/api/refrigerant-logs/admin/all`);
        url.searchParams.set("divisionKey", selectedDivision.key);

        const res = await fetch(url.toString(), {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await res.json();

        if (!res.ok) {
          setError(data?.error || "Failed to load refrigerant logs.");
          return;
        }

        setRefrigerantLogs(Array.isArray(data.logs) ? data.logs : []);
      } catch {
        setError("Could not reach API.");
      } finally {
        setLoadingRefrigerantLogs(false);
      }
    }

    void loadRefrigerantLogs();
  }, [selectedDivision?.key, selectedModuleKey]);

  useEffect(() => {
    async function loadSprayFoamLogs() {
      if (!selectedDivision?.key || selectedModuleKey !== "spray-foam-job-log") {
        setSprayFoamLogs([]);
        setLoadingSprayFoamLogs(false);
        return;
      }

      try {
        setLoadingSprayFoamLogs(true);
        setError("");

        const token = getStoredToken();
        const url = new URL(`${API_BASE}/api/spray-foam-logs/admin/all`);
        url.searchParams.set("divisionKey", selectedDivision.key);

        const res = await fetch(url.toString(), {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await res.json();

        if (!res.ok) {
          setError(data?.error || "Failed to load spray foam logs.");
          return;
        }

        setSprayFoamLogs(Array.isArray(data.logs) ? data.logs : []);
      } catch {
        setError("Could not reach API.");
      } finally {
        setLoadingSprayFoamLogs(false);
      }
    }

    void loadSprayFoamLogs();
  }, [selectedDivision?.key, selectedModuleKey]);

  const enabledModules = useMemo(
    () => modules.filter((row) => row.isEnabled && row.module.isActive),
    [modules]
  );

  const moduleItems = enabledModules.map((row) => ({
    key: row.module.key,
    name: row.module.name,
  }));

  const showingModulePicker = Boolean(selectedDivision && !selectedModuleKey);
  const showingRefrigerantRecords = selectedModuleKey === "refrigerant-log";
  const showingSprayFoamRecords = selectedModuleKey === "spray-foam-job-log";

  return (
    <Layout
      title="Reports"
      subtitle="Choose a division, then choose a report module, then review the records inside it."
    >
      <div className="grid gap-6">
        {!loadingDivisions ? (
          <ReportsDivisionSelect
            divisions={divisions}
            value={selectedDivisionId}
            onChange={setSelectedDivisionId}
          />
        ) : null}

        {loadingDivisions ? (
          <div className="rounded-3xl border border-white/10 bg-[#1a1a1a] p-5 text-white/70 shadow-2xl">
            Loading divisions...
          </div>
        ) : null}

        {error ? (
          <div className="rounded-3xl border border-red-500/20 bg-red-500/10 p-5 text-sm font-medium text-red-200">
            {error}
          </div>
        ) : null}

        {!loadingDivisions && !error && selectedDivision ? (
          <>
            {loadingModules ? (
              <div className="rounded-3xl border border-white/10 bg-[#1a1a1a] p-5 text-white/70 shadow-2xl">
                Loading modules...
              </div>
            ) : null}

            {!loadingModules && enabledModules.length === 0 ? (
              <div className="rounded-3xl border border-white/10 bg-[#1a1a1a] p-5 text-white/65 shadow-2xl">
                No enabled report modules found for this division.
              </div>
            ) : null}

            {!loadingModules && enabledModules.length > 0 && showingModulePicker ? (
              <ReportsModulePanel
                modules={moduleItems}
                selectedModuleKey={selectedModuleKey}
                onSelectModule={setSelectedModuleKey}
              />
            ) : null}

            {showingRefrigerantRecords ? (
              <div className="grid gap-4">
                <div className="flex items-center justify-between gap-4 rounded-3xl border border-white/10 bg-[#141414] p-5 shadow-2xl">
                  <div>
                    <div className="text-[12px] font-bold uppercase tracking-[0.24em] text-orange-400">
                      Records
                    </div>
                    <h3 className="mt-3 text-2xl font-black tracking-tight text-white">
                      Refrigerant Logs
                    </h3>
                  </div>

                  <button
                    type="button"
                    onClick={() => setSelectedModuleKey("")}
                    className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-white transition hover:bg-white/10"
                  >
                    Back to Modules
                  </button>
                </div>

                {loadingRefrigerantLogs ? (
                  <div className="rounded-3xl border border-white/10 bg-[#1a1a1a] p-5 text-white/70 shadow-2xl">
                    Loading refrigerant logs...
                  </div>
                ) : refrigerantLogs.length === 0 ? (
                  <div className="rounded-3xl border border-white/10 bg-[#1a1a1a] p-5 text-white/65 shadow-2xl">
                    No refrigerant logs found for this division.
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {refrigerantLogs.map((log) => (
                      <RefrigerantLogCard key={log.id} log={log} />
                    ))}
                  </div>
                )}
              </div>
            ) : null}

            {showingSprayFoamRecords ? (
              <div className="grid gap-4">
                <div className="flex items-center justify-between gap-4 rounded-3xl border border-white/10 bg-[#141414] p-5 shadow-2xl">
                  <div>
                    <div className="text-[12px] font-bold uppercase tracking-[0.24em] text-orange-400">
                      Records
                    </div>
                    <h3 className="mt-3 text-2xl font-black tracking-tight text-white">
                      Spray Foam Job Logs
                    </h3>
                  </div>

                  <button
                    type="button"
                    onClick={() => setSelectedModuleKey("")}
                    className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-white transition hover:bg-white/10"
                  >
                    Back to Modules
                  </button>
                </div>

                {loadingSprayFoamLogs ? (
                  <div className="rounded-3xl border border-white/10 bg-[#1a1a1a] p-5 text-white/70 shadow-2xl">
                    Loading spray foam job logs...
                  </div>
                ) : sprayFoamLogs.length === 0 ? (
                  <div className="rounded-3xl border border-white/10 bg-[#1a1a1a] p-5 text-white/65 shadow-2xl">
                    No spray foam job logs found for this division.
                  </div>
                ) : (
                  <div className="grid gap-3">
                    {sprayFoamLogs.map((log) => (
                      <SprayFoamLogCard key={log.id} log={log} />
                    ))}
                  </div>
                )}
              </div>
            ) : null}
          </>
        ) : null}
      </div>
    </Layout>
  );
}
